<section id="service">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="service-area">
					<!-- Start Service Title -->
					<div class="section-heading">
						<h2>Our Services</h2>
						<div class="line"></div>
					</div>
					<!-- Start Service Content -->
					<div class="service-content">
						<div class="row">
							<div class="col-lg-4 col-md-4">
								<div class="single-service">
									<div class="service-icon">
										<span class="fa fa-h-square service-icon-effect"></span>
									</div>
									<h3><a href="#">Mariage Therapy</a></h3>
									<p>Also known as couples therapy or couples counseling, is a type of psychotherapy or counseling that is specifically designed to help married or committed couples resolve conflicts, improve their communication, and enhance their overall relationship. The primary goal of marriage therapy is to assist couples in understanding and addressing the challenges they may be facing within their partnership.</p>
								</div>
							</div>
							<div class="col-lg-4 col-md-4">
								<div class="single-service">
									<div class="service-icon">
										<span class="fa fa-medkit service-icon-effect"></span>
									</div>
									<h3><a href="#">Grief Therapy</a></h3>
									<p> Also known as grief counseling or bereavement therapy, is a specialized form of psychotherapy or counseling aimed at helping individuals cope with and process the emotional and psychological challenges associated with grief and loss. Grief therapy provides support and guidance to people who are struggling with the profound sense of loss that often accompanies the death of a loved one or other significant life changes.</p>
								</div>
							</div>
							<div class="col-lg-4 col-md-4">
								<div class="single-service">
									<div class="service-icon">
										<span class="fa fa-user-md service-icon-effect"></span>
									</div>
									<h3><a href="#">Psychotherapy</a></h3>
									<p>Often referred to as talk therapy or counseling, is a therapeutic process that involves a trained mental health professional working with an individual, couple, family, or group to address emotional, psychological, and behavioral issues. The primary goal of psychotherapy is to improve a person's mental well-being, alleviate distress, and promote personal growth and self-awareness. It can be used to treat a wide range of emotional and mental health conditions, as well as to enhance overall mental and emotional resilience.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
