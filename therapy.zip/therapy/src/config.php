<?php
$con = mysqli_connect("localhost", "root", "", "project") or die(mysqli_error($con));
