<section id="extraFeatures">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="departments-area">
					<div class="section-heading">
						<h2>Information for the public</h2>
						<div class="line"></div>
					</div>
					<!-- Start Departments Accordion -->
					<div class="panel-group custom-panel" id="accordion">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
										Mariage Therapy <span class="fa fa-minus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseOne" class="panel-collapse collapse in">
								<div class="panel-body">
									<p> Also known as couples therapy or couples counseling, is a type of psychotherapy or counseling that is specifically designed to help married or committed couples resolve conflicts, improve their communication, and enhance their overall relationship. The primary goal of marriage therapy is to assist couples in understanding and addressing the challenges they may be facing within their partnership.</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
										Grief Therapy <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseTwo" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Also known as grief counseling or bereavement therapy, is a specialized form of psychotherapy or counseling aimed at helping individuals cope with and process the emotional and psychological challenges associated with grief and loss. Grief therapy provides support and guidance to people who are struggling with the profound sense of loss that often accompanies the death of a loved one or other significant life changes.</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
										Psychotherapy <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseThree" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Often referred to as talk therapy or counseling, is a therapeutic process that involves a trained mental health professional working with an individual, couple, family, or group to address emotional, psychological, and behavioral issues. The primary goal of psychotherapy is to improve a person's mental well-being, alleviate distress, and promote personal growth and self-awareness. It can be used to treat a wide range of emotional and mental health conditions, as well as to enhance overall mental and emotional resilience.</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
										 <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseFour" class="panel-collapse collapse">
								<div class="panel-body">
									<p> 
									</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
										 <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseFive" class="panel-collapse collapse">
								<div class="panel-body">
									<p></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="how-works-area">
					<div class="section-heading">
						<h2>How Do We Operate</h2>
						<div class="line"></div>
					</div>
					<div class="how-works">
						<ul class="nav nav-tabs" id="myTab">
							<li class="active"><a href="#experiment" data-toggle="tab">Appointment booking by victims</a></li>
							<li><a href="#monitor" data-toggle="tab">Victim visits therapist</a></li>
							<li><a href="#clean" data-toggle="tab">Victim clears with the specialists</a></li>
							<li><a href="#fast" data-toggle="tab">Fast</a></li>
							<li><a href="#support" data-toggle="tab">Support</a></li>
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane fade in active" id="experiment">
								<p>The accuracy of our  Therapy results over the different fields has been a result
									of the continous experiment carried out by our doctors to help the cause of the
									organisation which is to provide you the best possible service.</p>
								<img class="img-center" src="images/gallery/eservice_Diagnosis__Pathology_Pic_1.jpg" alt="img">
							</div>
							<div class="tab-pane fade " id="monitor">
								<p>The test conducted by our pathologist are always monitored by senior pathologists so
									to avoid mininimum discrepancy in the test results and even the test results an
									cross-checked.</p>
								<img class="img-center" src="images/gallery/istock_000014368289small.jpg" alt="img">
							</div>
							<div class="tab-pane fade " id="clean">
								<p>Integrity in the workspace is the most important thing in Speak Up.Each and
									every employee of the company maintains a level of self-integrity so as hold the
									integrity of company together.</p>
								<img class="img-center" src="images/gallery/Pathology.jpg" alt="img">
							</div>
							<div class="tab-pane fade " id="fast">
								<p>We at Speak Up believe that reports delayed is reports denied so our very
									objective is to provide fast and reliable reports to all customers without
									differences</p>
								<img class="img-center" src="images/gallery/HCNOCTN442-IMS-en_AA.png" alt="img">
							</div>
							<div class="tab-pane fade " id="support">
								<p>We are here for all your needs to provide the best in class therapy services</p>
								<img class="img-center" src="images/choose-us-img1.jpg" alt="img">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
