<section id="sliderArea">
	<!-- Start slider wrapper -->
	<div class="top-slider">
		<!-- Start First slide -->
		<div class="top-slide-inner">
			<div class="slider-img">
				<img alt="" src="images/14.jpg">
			</div>
			<div class="slider-text">
				<h2>We offer both physical and online services<strong></strong></h2>
				<p><strong>SpeakUp</strong> 
				<div class="readmore_area">
					<a data-hover="Read More" href="#"><span>Read More</span></a>
				</div>
			</div>
		</div>
		<!-- End First slide -->

		<!-- Start 2nd slide -->
		<div class="top-slide-inner">
			<div class="slider-img">
				<img alt="" src="images/15.jpg">
			</div>
			<div class="slider-text">
				<h2>We offer both physical and online services<strong></strong> </h2>
				<p><strong>SpeakUp</strong> 
				</p>
				<div class="readmore_area">
					<a data-hover="Read More" href="#"><span>Read More</span></a>
				</div>
			</div>
		</div>
		<!-- End 2nd slide -->

		<!-- Start Third slide -->
		<div class="top-slide-inner">
			<div class="slider-img">
				<img alt="" src="images/7.jpg">
			</div>
			<div class="slider-text">
				<h2>We offer both physical and online services<strong></strong></h2>
				<p><strong>SpeakUp</strong> 
				</p>
				<div class="readmore_area">
					<a data-hover="Read More" href="#"><span>Read More</span></a>
				</div>
			</div>
		</div>
		<!-- End Third slide -->

		<!-- Start Fourth slide -->
		<div class="top-slide-inner">
			<div class="slider-img">
				<img alt="" src="images/12.jpg">
			</div>
			<div class="slider-text">
				<h2>We offer both physical and online services<strong></strong></h2>
				<p><strong>SpeakUp</strong> 
				</p>
				<div class="readmore_area">
					<a data-hover="Read More" href="#"><span>Read More</span></a>
				</div>
			</div>
		</div>
		<!-- End Fourth slide -->

		<!-- Start Fifth slide -->
		<div class="top-slide-inner">
			<div class="slider-img">
				<img alt="" src="images/9.jpg">
			</div>
			<div class="slider-text">
				<h2>We offer both physical and online services<strong></strong> </h2>
				<p><strong>SpeakUp</strong> 
				</p>
				<div class="readmore_area">
					<a data-hover="Read More" href="#"><span>Read More</span></a>
				</div>
			</div>
		</div>
		<!-- End Fifth slide -->
	</div><!-- /top-slider -->
</section>
