<footer id="footer">
	<!-- Start Footer Top -->
	<div class="footer-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-3">
					<div class="single-footer-widget">
						<div class="section-heading">
							<h2>About Us</h2>
							<div class="line"></div>
						</div>
						<p>SpeakUp is an online and mobile therapy company based in Kenya. It was founded by Mwanzia Kathenge  in 2023. SpeakUp users have access to licensed therapists through the website.</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-3">
					<div class="single-footer-widget">
						<div class="section-heading">
							<h2>Our Therapy Services</h2>
							<div class="line"></div>
						</div>
						<ul class="footer-service">
							<li><a href="#"><span class="fa fa-check"></span>Mariage Therapy</a></li>
							<li><a href="#"><span class="fa fa-check"></span>Grief Therapy</a></li>
							<li><a href="#"><span class="fa fa-check"></span>Psychotherapy</a></li>
							<li><a href="#"><span class="fa fa-check"></span>Counselling</a></li>
							<li><a href="#"><span class="fa fa-check"></span>General Mental Welness</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-3">
					<div class="single-footer-widget">
						<div class="section-heading">
							<h2>Tags</h2>
							<div class="line"></div>
						</div>
						<ul class="tag-nav">
							<li><a href="#">Depression</a></li>
							<li><a href="#">Anxiety</a></li>
							<li><a href="#">PTSD</a></li>
							<li><a href="#">Trauma</a></li>
							<li><a href="#">Addiction</a></li>
							<li><a href="#">Early Marriage</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-3">
					<div class=" single-footer-widget ">
						<div class=" section-heading">
							<h2>Contact Info</h2>
							<div class="line"></div>
						</div>
						<p>Feel free to contact us any moment using any of the details provided below.</p>
						<address class="contact-info">
							<p><span class="fa fa-home"></span>
								TUM,Medical Engineering Department.<i></i></p>
							<p><span class="fa fa-phone"></span>+254792708456</p>
							<p><span class="fa fa-envelope"></span>mwanziakathenge@gmail.com</p>
						</address>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Start Footer Middle -->
	<div class="footer-middle">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="footer-copyright">
						<?= "<p>&copy; Copyright 2023-" . date("Y") . " <a href=\"index.html\">SpeakUp</a></p>"; ?>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="footer-social">
						<a href=""><span class="fa fa-facebook"></span></a>
						<a href=""><span class="fa fa-twitter"></span></a>
						<a href=""><span class="fa fa-github"></span></a>
						<a href=""><span class="fa fa-linkedin"></span></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Start Footer Bottom -->
	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p>Designed & Developed By <a rel="nofollow">Mwanzia Kathenge(BSMD/188J/2019)-Kenya</a></p>
				</div>
			</div>
		</div>
	</div>
</footer>
